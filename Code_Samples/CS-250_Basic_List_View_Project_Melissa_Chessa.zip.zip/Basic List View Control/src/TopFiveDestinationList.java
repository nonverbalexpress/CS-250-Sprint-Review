import java.awt.*;
import java.net.URI;
import javax.swing.*;
import javax.swing.event.HyperlinkEvent;

// Main class clearly required as program entry point
public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TopDestinationListFrame frame = new TopDestinationListFrame();
            frame.setVisible(true);
        });
    }
}

// Frame class containing GUI customizations for SNHU Travel Agency
class TopDestinationListFrame extends JFrame {

    public TopDestinationListFrame() {
        super("Top 5 Destination List - SNHU Travel Agency");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        // SNHU official colors clearly used (SNHU Blue: #003DA5, SNHU Gold: #FFC72C)
        // Source: https://www.snhu.edu
        getContentPane().setBackground(new Color(0x003DA5));

        // HTML Content clearly formatted with SNHU colors, clickable travel links, and embedded images
        String htmlContent = "<html>"
            + "<h1 style='color:#FFC72C; text-align:center;'>SNHU Travel Agency - Melissa Chessa's Top 5 Destinations for 2025!</h1>"
            + "<ol style='color:#FFFFFF;'>"

            // Destination 1: London, U.K.
            + "<li><b>London, U.K.</b> – Experience epic nightlife and historic landmarks! "
            + "<a href='https://www.expedia.com/London.d178279.Destination-Travel-Guides' style='color:#FFC72C;'>Book Now!</a><br>"
            + "<img src='" + getClass().getResource("/resources/london.jpg") + "' width='400' height='300'><br>"
            + "<small>Image Credit: Celsoazevedo, CC BY 4.0, "
            + "<a style='color:#FFC72C;' href='https://commons.wikimedia.org/wiki/File:Big_Ben,_Elizabeth_Tower,_Evening_November_2024.jpg'>Wikimedia Commons</a></small><br><br></li>"

            // Destination 2: Bali, Indonesia
            + "<li><b>Bali, Indonesia</b> – Chill beaches, waterfalls, and vibrant culture! "
            + "<a href='https://www.tripadvisor.com/Tourism-g294226-Bali-Vacations.html' style='color:#FFC72C;'>Book Now!</a><br>"
            + "<img src='" + getClass().getResource("/resources/bali.jpg") + "' width='400' height='300'><br>"
            + "<small>Image Credit: Hendri Suhandi, CC BY 4.0, "
            + "<a style='color:#FFC72C;' href='https://commons.wikimedia.org/wiki/File:Learn_to_Dance.jpg'>Wikimedia Commons</a></small><br><br></li>"

            // Destination 3: Dubai, U.A.E.
            + "<li><b>Dubai, U.A.E.</b> – Luxury malls, adrenaline-packed adventures! "
            + "<a href='https://www.expedia.com/Dubai.d1079.Destination-Travel-Guides' style='color:#FFC72C;'>Book Now!</a><br>"
            + "<img src='" + getClass().getResource("/resources/dubai.jpg") + "' width='400' height='300'><br>"
            + "<small>Image Credit: Chris Sétian, CC BY 3.0, "
            + "<a style='color:#FFC72C;' href='https://commons.wikimedia.org/wiki/File:Dubai_Marina_At_Night_(251388905).jpeg'>Wikimedia Commons</a></small><br><br></li>"

            // Destination 4: Sicily, Italy
            + "<li><b>Sicily, Italy</b> – Beautiful beaches, history, and amazing food! "
            + "<a href='https://www.tripadvisor.com/Tourism-g187886-Sicily-Vacations.html' style='color:#FFC72C;'>Book Now!</a><br>"
            + "<img src='" + getClass().getResource("/resources/sicily.jpg") + "' width='400' height='300'><br>"
            + "<small>Image Credit: Ralf Steinberger, CC BY 2.0, "
            + "<a style='color:#FFC72C;' href='https://commons.wikimedia.org/wiki/File:Old_town_in_the_Baroque_city_of_Caltagirone_in_Sicily,_Italy.jpg'>Wikimedia Commons</a></small><br><br></li>"

            // Destination 5: Paris, France
            + "<li><b>Paris, France</b> – Iconic sights, romantic atmosphere! "
            + "<a href='https://www.expedia.com/Paris.d179898.Destination-Travel-Guides' style='color:#FFC72C;'>Book Now!</a><br>"
            + "<img src='" + getClass().getResource("/resources/paris.jpg") + "' width='400' height='300'><br>"
            + "<small>Image Credit: Jorge Royan, CC BY-SA 3.0, "
            + "<a style='color:#FFC72C;' href='https://commons.wikimedia.org/wiki/File:Paris_-_The_Eiffel_Tower_in_spring_-_2307.jpg'>Wikimedia Commons</a></small></li>"

            + "</ol></html>";

        // JEditorPane chosen to enable clickable hyperlinks in GUI
        JEditorPane editorPane = new JEditorPane("text/html", htmlContent);
        editorPane.setEditable(false);
        editorPane.setBackground(new Color(0x003DA5));
        editorPane.setCaretPosition(0);

        // Listener to handle clickable links clearly, opens default web browser
        editorPane.addHyperlinkListener(e -> {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                try {
                    Desktop.getDesktop().browse(new URI(e.getURL().toString()));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Unable to open link.");
                }
            }
        });

        // JScrollPane clearly wraps the editorPane allowing scrollability
        JScrollPane scrollPane = new JScrollPane(editorPane);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }
}

/*
 * PROJECT REFERENCES:
 *
 * SNHU Official Colors:
 * - SNHU: https://www.snhu.edu
 *
 * Top Destinations List Source:
 * - Tripadvisor 2025 Travelers' Choice Awards:
 *   https://tripadvisor.mediaroom.com/2025-01-09-Tripadvisor-Reveals-2025s-Must-Visit-Destinations-Top-Picks-From-Travelers-Around-the-World
 *
 * Images & Licenses:
 * - London: https://commons.wikimedia.org/wiki/File:Big_Ben,_Elizabeth_Tower,_Evening_November_2024.jpg (CC BY 4.0)
 * - Bali: https://commons.wikimedia.org/wiki/File:Learn_to_Dance.jpg (CC BY 4.0)
 * - Dubai: https://commons.wikimedia.org/wiki/File:Dubai_Marina_At_Night_(251388905).jpeg (CC BY 3.0)
 * - Sicily: https://commons.wikimedia.org/wiki/File:Old_town_in_the_Baroque_city_of_Caltagirone_in_Sicily,_Italy.jpg (CC BY 2.0)
 * - Paris: https://commons.wikimedia.org/wiki/File:Paris_-_The_Eiffel_Tower_in_spring_-_2307.jpg (CC BY-SA 3.0)
 *
 * Customized specifically for SNHU Travel Agency Project by Melissa Chessa.
 */