import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Color;

public class SlideShow extends JFrame {

	// Declare UI components
	private JPanel slidePane; // Holds image slides
	private JPanel textPane;  // Holds text content under slides
	private JPanel buttonPane; // Holds navigation buttons
	private CardLayout card;  // Manages image cards
	private CardLayout cardText; // Manages text cards
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Constructor to launch the slideshow setup.
	 */
	public SlideShow() {
		initComponent();
	}

	/**
	 * Initializes all GUI components and layout behavior.
	 */
	private void initComponent() {
		// Initialize layout managers and panels
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		slidePane.setBackground(new Color(0x0033A0)); // SNHU Blue background
		textPane = new JPanel();
		textPane.setBackground(Color.DARK_GRAY);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		// Set main frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Wellness Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Set layout behavior
		slidePane.setLayout(card);
		textPane.setLayout(cardText);

		// Populate slides
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblSlide.setHorizontalAlignment(SwingConstants.CENTER); // Center image
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		// Add components
		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		// Setup navigation buttons
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Navigate to the previous slide and text.
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}

	/**
	 * Navigate to the next slide and text.
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Load image tags with fixed width only (no distortion).
	 */
	private String getResizeIcon(int i) {
		String base = "<html><body><img width='800' src='";
		String end = "'></body></html>";
		if (i==1){
			return base + getClass().getResource("/resources/bali.jpg") + end;
		} else if (i==2){
			return base + getClass().getResource("/resources/dubai.jpg") + end;
		} else if (i==3){
			return base + getClass().getResource("/resources/london.jpg") + end;
		} else if (i==4){
			return base + getClass().getResource("/resources/paris.jpg") + end;
		} else {
			return base + getClass().getResource("/resources/sicily.jpg") + end;
		}
	}

	/**
	 * Slide captions styled with white text and bold titles.
	 */
	private String getTextDescription(int i) {
		String text = "";
		if (i==1){
			text = "<html><body><font size='5' color='white'><b>#1 Bali Spa Retreat</b></font><br><font color='white'>Traditional healing and peaceful rituals in Ubud’s serene beauty.</font></body></html>";
		} else if (i==2){
			text = "<html><body><font size='5' color='white'><b>#2 Dubai Night Detox</b></font><br><font color='white'>Relax in luxury and tranquility beneath the desert skyline.</font></body></html>";
		} else if (i==3){
			text = "<html><body><font size='5' color='white'><b>#3 London Mindfulness Tour</b></font><br><font color='white'>Balance your mind with calm city strolls and garden escapes.</font></body></html>";
		} else if (i==4){
			text = "<html><body><font size='5' color='white'><b>#4 Paris Spring Wellness Escape</b></font><br><font color='white'>Enjoy fresh air and floral serenity with clean eats and café calm.</font></body></html>";
		} else if (i==5){
			text = "<html><body><font size='5' color='white'><b>#5 Sicily Slow-Living Retreat</b></font><br><font color='white'>Unplug and unwind among rustic charm and Mediterranean breeze.</font></body></html>";
		}
		return text;
	}

	/**
	 * Launch the application GUI.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}